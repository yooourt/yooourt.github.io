set -e


install_requirements() {
    sudo apt-get install libsdl2-image-dev
}


create_axe_folder() {
    sudo mkdir -p /usr/local/axe/bin
    sudo chown -R `whoami` /usr/local/axe
}


backup() {
    # 备份上个版本的二进制
    if [ -e /usr/local/axe/bin/gualang.axe ]
    then
        cp /usr/local/axe/bin/gualang.axe /usr/local/axe/bin/gualang.axe.backup
    fi
}


download() {
    # 文件夹不存在，则新建
    if [ ! -d /usr/local/axe/bin ] 
    then
        create_axe_folder
    fi

    # 下载 gualang.axe
    curl -o /usr/local/axe/bin/gualang.axe https://gitee.com/kuaibiancheng/gualang/raw/master/gualang_linux/gualang.axe
    chmod +x /usr/local/axe/bin/gualang.axe

    # 下载 glbk.axe
    curl -o /usr/local/axe/bin/glbk.axe https://gitee.com/kuaibiancheng/gualang/raw/master/gualang_linux/bin/glbk.axe
    chmod +x /usr/local/axe/bin/glbk.axe
}


install_gualang() {
    # 软链接到 /usr/local/bin
    sudo ln -sf /usr/local/axe/bin/gualang.axe /usr/local/bin/gualang.axe
}


install_glbk() {
    # 软链接到 /usr/local/bin
    sudo ln -sf /usr/local/axe/bin/glbk.axe /usr/local/bin/glbk.axe
}


hint() {
    echo "🍉🍉🍉 install gualang.axe and glbk.axe successfully"
}


__main() {
    install_requirements
    backup
    download
    install_gualang
    install_glbk
    hint
}

__main